
<table>
	<tr>
		<th>dependency</th>
		<th>version</th>
		<th>url</th>
	</tr>
	<tr>
		<td>Deployment Descriptor</td><td>6.0</td><td>https://jakarta.ee/specifications/servlet/6.0/</td>
	</tr>
	<tr>
		<td>Jakarta Web API</td><td>10.0.0</td><td>https://jakarta.ee/specifications/webprofile/10/</td>
	</tr>
	<tr>
		<td>Jakarta JSTL</td><td>3.0.0</td><td>https://jakarta.ee/specifications/tags/3.0/</td>
	</tr>
	<tr>
		<td>Spring MVC</td><td>6.1.1</td><td>https://docs.spring.io/spring-framework/reference/index.html</td>
	</tr>
	<tr>
		<td>Spring Security</td><td>6.2.0</td><td>https://docs.spring.io/spring-security/reference/index.html</td>
	</tr>
	<tr>
		<td>Hibernate Validator</td><td>8.0.0.Final</td><td>https://hibernate.org/validator/releases/8.0/</td>
	</tr>
</table>
Tested on Apache Tomcat/10.1.16 (https://tomcat.apache.org/download-10.cgi)
